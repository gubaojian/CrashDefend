package com.cainiao.wireless.crashdefendkit.page;

public class PageNames {


    /**
     * 安全防护sdk
     * */
    public static final String CRASH_DEFEND_PAGE = "CrashDefend";
    public static final String CRASH_DEFEND_CONTROL = "CrashDefend";

    /**
     * 安全防护uikit库
     * */
    public static final String CRASH_KIT_PAGE = "CrashKit";
    public static final String CRASH_KIT_CONTROL = "CrashKit";



}
