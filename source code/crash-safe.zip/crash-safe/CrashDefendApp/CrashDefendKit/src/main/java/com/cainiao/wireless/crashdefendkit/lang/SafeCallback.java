package com.cainiao.wireless.crashdefendkit.lang;

/**
 *  安全回调接口
 * */
public interface SafeCallback {
}
