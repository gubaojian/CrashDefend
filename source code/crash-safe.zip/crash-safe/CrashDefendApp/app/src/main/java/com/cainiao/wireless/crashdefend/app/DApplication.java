package com.cainiao.wireless.crashdefend.app;

import android.app.Application;

import com.cainiao.wireless.crashdefendkit.CrashDefendInit;

public class DApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        CrashDefendInit.init(getApplicationContext());
    }
}
