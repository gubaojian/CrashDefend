package com.cainiao.wireless.crashdefend;

public class HandoverRequestConstants {


    /**
     * 拦截类型 对应参数interceptOperate
     * CHOOSE:选择是否拦截
     * INTERCEPT:拦截
     * PASS:不拦截
     */
    public  final String INTERCEPT_CHOOSE = "CHOOSE";
    public  final String INTERCEPT_INTERCEPT = "INTERCEPT";
    public  final String INTERCEPT_PASS = "PASS";
    /**
     * 操作类型 用于参数action 用于区分不同的实操，后端用于服务路由
     * INLAND_OPT_DISPATCH: 发货
     * INLAND_OPT_DISPATCH_HANDOVER: 发货装车
     * INLAND_OPT_HANDOVER: 装车
     * INLAND_OPT_CANCEL_HANDOVER: 取消装车
     * INLAND_OPT_CANCEL_DISPATCH: 取消发货
     */
    public  final String DO_CONSIGNMENT = "INLAND_OPT_DISPATCH";
    public  final String DO_CONSIGNMENT_AND_LOADCAR = "INLAND_OPT_DISPATCH_HANDOVER";
    public  final String DO_LOADCAR = "INLAND_OPT_HANDOVER";
    public  final String DO_CANCEL_LOADCAR = "INLAND_OPT_CANCEL_HANDOVER";
    public  final String DO_CANCEL_CONSIGNMENT = "INLAND_OPT_CANCEL_DISPATCH";
    /**
     * 弹窗类型 对应参数confirmType，用于区分弹怎样的窗，弹窗若需要再次请求，需要在请求中带上这个参数
     *
     * B2B_PACKAGE_NOT_MERGED B2B货物未集包完成就发货
     *      B2B货物：给商家的货物，通常是成批发，如果未集包到一起，商家就要分两次收取，造成麻烦，所以我们希望这些包裹集到一起
     * B2B_PACKAGE_WITHOUT_DISPATCH_ORDER  B2B运单无调度信息（当前B2B运单还没有安排车辆调度）
     * INTERCEPT_WAYBILL 拦截件
     * HANDOVER_VEHICLE_VERIFY 流向维度切换
     * CANCEL_CONFIRM 取消装车，取消发货时弹窗提醒
     */
    public  final String NOT_MERGED = "B2B_PACKAGE_NOT_MERGED";
    public  final String WITHOUT_DISPATCH_ORDER = "B2B_PACKAGE_WITHOUT_DISPATCH_ORDER";
    public  final String INTERCEPT = "INTERCEPT_WAYBILL";
    public  final String FLOW_CONFIRM = "HANDOVER_VEHICLE_VERIFY";
    public  final String CANCEL_CONFIRM = "CANCEL_HANDOVER";
    /**
     * 弹窗code 用于弹窗选择时，区分具体的弹窗发送者
     *
     * REQUEST_INTERCEPT 拦截件
     * NOT_MERGED_CONFIRM b2b货物未集包完成
     * REQUEST_FLOW_CONFIRM 流向维度切换
     * REQUEST_WITHOUT_DISPATCH_ORDER B2B运单无调度信息
     * NO_CONFIRM 不是弹窗确认
     */
    public  final int REQUEST_INTERCEPT = 10002;
    public  final int REQUEST_NOT_MERGED = 10012;
    public  final int REQUEST_FLOW_CONFIRM = 10022;
    public  final int REQUEST_WITHOUT_DISPATCH_ORDER = 10032;
    public  final int REQUEST_CANCEL = 10042;
    public  final int NO_CONFIRM = 0;
    /**
     * 流向校验开关
     * */
    public  final int REQUEST_DIR_CHECK = 10052;
}
