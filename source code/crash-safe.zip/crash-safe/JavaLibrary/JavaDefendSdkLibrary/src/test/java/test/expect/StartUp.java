package test.expect;

public class StartUp {

    /**
    public static void doTaskOne(){
        StopWatch watch = new StopWatch();
        watch.start();
        // some worker code
        watch.stop();
    }

    public static void doTaskTwo(){
        StopWatch watch = new StopWatch();
        watch.start();
        // some worker code
        watch.stop();
    }

    public static void doTaskThree(){
        StopWatch watch = new StopWatch();
        watch.start();
        // some worker code
        watch.stop();
    }
     */
}
