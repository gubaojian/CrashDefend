mvn jar:jar deploy:deploy 
