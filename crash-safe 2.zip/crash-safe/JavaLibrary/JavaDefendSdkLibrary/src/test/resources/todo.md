1、类名字替换， 通过替换类使用实现更强的安全防护。


<replaceClass class="android.support.v7.widget.GapWorker" replace="" >
</replaceClass>

asm 类替换等。