package test;

public class Rectangle {
}
