package test;

import java.io.Serializable;

public class JavaBeanTest implements Serializable {

    private static final long serialVersionUID = -8119569305632543545L;

    public static void NoneHandleMethod(){
        System.out.println("Hello World Java Bean");
    }
}
