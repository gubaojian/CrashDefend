package test.exclude;

public class ExcludeTest {


    public Object testReturnObject(){
        return  null;//
    }

}
