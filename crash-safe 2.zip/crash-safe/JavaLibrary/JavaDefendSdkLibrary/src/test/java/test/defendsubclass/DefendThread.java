package test.defendsubclass;

public class DefendThread extends Thread {
    @Override
    public void run() {
        super.run();
    }
}
