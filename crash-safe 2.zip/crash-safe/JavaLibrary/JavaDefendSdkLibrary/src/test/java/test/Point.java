package test;

public class Point {
}
