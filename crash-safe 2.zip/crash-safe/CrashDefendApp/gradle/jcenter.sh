./gradlew clean build bintrayUpload -PbintrayUser=gubaojian -PbintrayKey=fb3fa84de3315230e575ba114fc38f7e36148957 -PdryRun=false

