package com.efurture.wireless.defend.plugin;

public class WeaverCode {


    public static String CODE_START = "{com.efurture.wireless.defend.DefendReporter.onCatch($e);";

    public static String CODE_END = "}";



    public static String REPORTER_CODE = "com.efurture.wireless.defend.DefendReporter.onCatch(e);";
}
