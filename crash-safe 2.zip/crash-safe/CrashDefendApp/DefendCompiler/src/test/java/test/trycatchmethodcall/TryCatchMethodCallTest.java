package test.trycatchmethodcall;

public class TryCatchMethodCallTest {


    public void testMethodCall(){
        this.dangerMethod();
    }


    public void dangerMethod(){

    }


}
