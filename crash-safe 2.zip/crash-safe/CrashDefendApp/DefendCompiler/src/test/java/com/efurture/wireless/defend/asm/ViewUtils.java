package com.efurture.wireless.defend.asm;

public class ViewUtils {

    public Object post(Runnable runnable){
        System.out.println("post");
        return  null;
    }

    public void testCallPost(){

    }

    public void doExp(Runnable a) {

    }


    public static Object staticPost(Runnable runnable){
        System.out.println("staticPost");
        return null;
    }
}
