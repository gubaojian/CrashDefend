./gradlew :DefendReporter:assemble
./gradlew :DefendReporter:uploadArchives

./gradlew :DefendCompiler:assemble
./gradlew :DefendCompiler:uploadArchives


./gradlew :CrashDefendSdk:assemble
./gradlew :CrashDefendSdk:uploadArchives

./gradlew :DefendPlugin:assemble
./gradlew :DefendPlugin:uploadArchives



